# Changelog

All notable changes to the Redirect Plus plugin will be documented in this file.

## [1.1.0] - 2025-10-30

### Major Changes
- **New Architecture**: Changed from automatic callback to server-configured custom 404 page
- **Unified Interface**: Combined report and settings into single page with tabbed navigation
- **Better Admin Placement**: Moved from Tools to General section in Site Administration

### Added
- Custom 404 error page (`error404.php`) that logs errors before displaying content
- Settings tab with configuration options:
  - Enable/disable 404 tracking
  - Redirect to custom URL option
  - Custom HTML message option
- Setup Instructions tab with:
  - Server-specific configuration instructions (Apache, Nginx, Plesk)
  - Test button to verify 404 tracking is working
  - Copy-ready configuration snippets
- Tabbed interface for better organization
- Comprehensive server configuration documentation

### Changed
- Removed `tool_redirectplus_after_http_headers()` callback function
- Main page now accessible from Site administration > Redirect Plus (General section)
- Updated all documentation to reflect new setup process

### Technical Changes
- Plugin now requires server-level 404 error page configuration
- More reliable 404 detection (server-level vs PHP-level)
- Improved user experience with custom messages or redirects
- Better frankenstyle naming consistency

## [1.0.0] - 2025-10-30

### Added
- Initial release of Redirect Plus
- Automatic 404 error logging functionality
- Comprehensive 404 error report page with pagination
- Database table `tool_redirectplus_404` for storing error records
- Delete individual error records functionality
- Delete all error records functionality
- Privacy API implementation for GDPR compliance
- Logger class for managing 404 error records
- Full frankenstyle naming convention compliance
- Support for Moodle 4.3, 4.4, 4.5, 5.0, and 5.1
- User-friendly admin interface in Tools menu
- IP address tracking (IPv4 and IPv6 support)
- User agent tracking
- Referrer URL tracking
- User association with 404 errors
- Timestamp recording
- Comprehensive documentation (README.md and INSTALL.md)
- Custom CSS styling for report page
- Language strings (English)
- Installation and upgrade scripts

### Features
- Zero configuration required - works immediately after installation
- Automatic detection of 404 HTTP responses
- Callback function `tool_redirectplus_after_http_headers()` for error capture
- Admin-only access (requires `moodle/site:config` capability)
- Responsive table design
- Pagination support (50 records per page by default)
- Database indexes for optimal performance
- Foreign key relationship to user table
- Error handling with silent failure to avoid breaking pages
- Debugging support for troubleshooting

### Technical Details
- All variables and functions use `tool_redirectplus_` prefix
- Implements `\core_privacy\local\metadata\provider`
- Implements `\core_privacy\local\request\core_userlist_provider`
- Implements `\core_privacy\local\request\plugin\provider`
- Database table indexes on `timecreated` and `userid` fields
- Supports up to 45 characters for IP addresses (IPv6 compatible)
- Text fields for URL, referrer, and user agent (no length limits)

### Security
- Admin capability check on report page
- Session key validation for delete actions
- Confirmation dialogs for destructive operations
- Escaped output to prevent XSS attacks
- Foreign key constraint to user table

### Compatibility
- Minimum Moodle version: 4.3 (2023100900)
- Tested with Moodle 4.3, 4.4, 4.5, 5.0, and 5.1
- Minimum PHP version: 7.4
- Database support: MySQL, MariaDB, PostgreSQL (all Moodle-supported databases)

---

## Future Enhancements (Planned)

Potential features for future versions:
- Export 404 errors to CSV
- Filter/search functionality on report page
- Custom retention policies for old records
- Email notifications for repeated 404 errors
- Statistics dashboard with charts
- Automatic redirect suggestions
- Integration with course restoration
- API for external access
- Bulk redirect management
- Pattern matching for similar URLs

---

## Version Numbering

This plugin follows [Semantic Versioning](https://semver.org/):
- MAJOR version for incompatible API changes
- MINOR version for backwards-compatible functionality additions
- PATCH version for backwards-compatible bug fixes

## Support

For bug reports, feature requests, or questions:
- Email: support@gwizit.com
- Copyright: 2025 G Wiz IT Solutions

## License

GNU General Public License v3.0 or later
See LICENSE.md for full license text
