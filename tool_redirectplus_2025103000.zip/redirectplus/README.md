# Redirect Plus #

A Moodle admin tool plugin that automatically tracks and logs all 404 (Page Not Found) errors occurring on your Moodle site.

## Description ##

Redirect Plus helps you identify broken links, missing pages, and navigation issues by recording every 404 error that occurs on your Moodle site. The plugin captures comprehensive information about each error including:

- The URL that generated the 404 error
- The referrer (where the user came from)
- User information (who encountered the error)
- IP address
- User agent (browser/device information)
- Timestamp

This information is invaluable for:
- Identifying and fixing broken links
- Improving site navigation
- Understanding user behavior
- Maintaining a better user experience

## Features ##

- **Automatic 404 Error Logging**: No configuration needed - works automatically after installation
- **Comprehensive Error Report**: View all 404 errors in an easy-to-read table format
- **User-Friendly Interface**: Access the report from Site administration > Tools > Redirect Plus
- **Record Management**: Delete individual records or clear all records at once
- **Pagination Support**: Easily browse through large numbers of errors
- **Full User Context**: See which users encountered errors and when
- **Compatible with Moodle 4.3, 4.4, 4.5, 5.0, and 5.1**

## Requirements ##

- Moodle 4.3 or later (compatible with 4.3, 4.4, 4.5, 5.0, and 5.1)
- PHP 7.4 or later

## Installation ##

### Method 1: Installing via uploaded ZIP file ###

1. Download or create a ZIP file of the plugin
2. Log in to your Moodle site as an admin and go to **Site administration > Plugins > Install plugins**
3. Upload the ZIP file with the plugin code
4. Check the plugin validation report and finish the installation
5. The database table `tool_redirectplus_404` will be created automatically

### Method 2: Installing manually ###

1. Extract the plugin files
2. Copy the `redirectplus` folder to `{your/moodle/dirroot}/admin/tool/redirectplus`
3. Log in to your Moodle site as an admin and go to **Site administration > Notifications**
4. Follow the on-screen instructions to complete the installation

### Method 3: Installing via command line ###

1. Copy the plugin files to `{your/moodle/dirroot}/admin/tool/redirectplus`
2. Run the upgrade script:
   ```bash
   php admin/cli/upgrade.php
   ```

## Setup ##

**No additional setup is required!** The plugin works automatically after installation.

- 404 errors will be logged automatically as they occur
- No configuration or settings changes are needed
- The plugin uses Moodle's built-in `after_http_headers` callback to detect 404 errors

## Usage ##

### Viewing the 404 Error Report ###

1. Log in as an administrator
2. Navigate to **Site administration > Tools > Redirect Plus**
3. You'll see a table listing all recorded 404 errors with the following information:
   - URL that generated the error
   - Referrer (where the user came from)
   - User who encountered the error
   - IP address
   - User agent (browser/device)
   - Date and time

### Managing Records ###

- **Delete a single record**: Click the "Delete" button next to any record
- **Delete all records**: Click the "Delete All Records" button at the top of the page
- Both actions require confirmation before proceeding

### Pagination ###

- By default, 50 records are shown per page
- Use the pagination controls at the bottom to navigate through multiple pages
- You can adjust the number of records per page using the `perpage` URL parameter

## How It Works ##

The plugin implements Moodle's `tool_redirectplus_after_http_headers()` callback function, which is automatically called after HTTP headers are sent. When a 404 error occurs (HTTP response code 404), the plugin:

1. Captures the current URL
2. Records the referrer (if available)
3. Logs the user ID (or 0 for guest users)
4. Saves the IP address
5. Stores the user agent string
6. Records the timestamp
7. Inserts all this information into the database table

All function and variable names follow Moodle's frankenstyle naming convention (prefixed with `tool_redirectplus_`).

## Database Schema ##

The plugin creates one table: `tool_redirectplus_404`

| Field | Type | Description |
|-------|------|-------------|
| id | int(10) | Primary key |
| url | text | The URL that generated the 404 error |
| referrer | text | The referrer URL (nullable) |
| userid | int(10) | Foreign key to user table (0 for guests) |
| timecreated | int(10) | Unix timestamp |
| ip | varchar(45) | IP address (supports IPv6) |
| useragent | text | User agent string (nullable) |

## Permissions ##

Access to the 404 Error Report requires the `moodle/site:config` capability (site administrators only).

## Privacy ##

This plugin stores the following user data:
- User ID of who encountered the 404 error
- IP address
- User agent (browser information)

This data is used solely for site administration and debugging purposes. Site administrators should be aware of this when considering privacy policies and GDPR compliance.

## Troubleshooting ##

**404 errors are not being logged:**
- Verify the plugin is installed correctly
- Check that the `tool_redirectplus_404` database table exists
- Ensure debugging is enabled to see any error messages: Site administration > Development > Debugging
- Check the web server error logs

**Cannot access the report page:**
- Ensure you're logged in as a site administrator
- Verify you have the `moodle/site:config` capability

**Performance concerns with large datasets:**
- The plugin automatically uses pagination (50 records per page)
- Consider periodically deleting old records using the "Delete All Records" feature
- Records are indexed by `timecreated` and `userid` for optimal query performance

## Support ##

For issues, questions, or contributions, please contact:
- Email: support@gwizit.com
- Copyright: 2025 G Wiz IT Solutions

## License ##

Copyright 2025 G Wiz IT Solutions <support@gwizit.com>

This program is free software: you can redistribute it and/or modify it under
the terms of the GNU General Public License as published by the Free Software
Foundation, either version 3 of the License, or (at your option) any later
version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
PARTICULAR PURPOSE.  See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with
this program.  If not, see <https://www.gnu.org/licenses/>.
