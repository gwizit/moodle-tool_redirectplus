<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Library functions for tool_redirectplus.
 *
 * @package     tool_redirectplus
 * @copyright   2025 G Wiz IT Solutions <support@gwizit.com>
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

/**
 * Callback function to capture 404 errors.
 *
 * This function is automatically called by Moodle when HTTP headers are sent.
 * It checks if a 404 error has occurred and logs it to the database.
 *
 * @return void
 */
function tool_redirectplus_after_http_headers() {
    global $DB, $USER;

    // Check if we have a 404 error.
    if (http_response_code() === 404) {
        try {
            $tool_redirectplus_record = new stdClass();
            $tool_redirectplus_record->url = qualified_me();
            $tool_redirectplus_record->referrer = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : '';
            $tool_redirectplus_record->userid = $USER->id ?? 0;
            $tool_redirectplus_record->timecreated = time();
            $tool_redirectplus_record->ip = getremoteaddr();
            $tool_redirectplus_record->useragent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';

            $DB->insert_record('tool_redirectplus_404', $tool_redirectplus_record);
        } catch (Exception $tool_redirectplus_exception) {
            // Silently fail to avoid breaking the page.
            debugging('tool_redirectplus: Failed to log 404 error - ' . $tool_redirectplus_exception->getMessage(), DEBUG_DEVELOPER);
        }
    }
}
