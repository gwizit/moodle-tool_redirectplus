<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Plugin strings are defined here.
 *
 * @package     tool_redirectplus
 * @category    string
 * @copyright   2025 G Wiz IT Solutions <support@gwizit.com>
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Redirect Plus';
$string['report404'] = '404 Error Report';
$string['report404desc'] = 'This report shows all 404 errors that have been recorded on your Moodle site. Use this information to identify broken links and fix them.';
$string['no404errors'] = 'No 404 errors have been recorded yet.';
$string['url'] = 'URL';
$string['referrer'] = 'Referrer';
$string['ipaddress'] = 'IP Address';
$string['useragent'] = 'User Agent';
$string['timecreated'] = 'Time Created';
$string['deleterecord'] = 'Delete Record';
$string['deleterecordconfirm'] = 'Are you sure you want to delete this 404 error record?';
$string['recorddeleted'] = 'Record deleted successfully.';
$string['deleteallrecords'] = 'Delete All Records';
$string['deleteallrecordsconfirm'] = 'Are you sure you want to delete ALL 404 error records? This action cannot be undone.';
$string['allrecordsdeleted'] = 'All records deleted successfully.';
$string['deleteduser'] = 'Deleted user';
$string['unknownuser'] = 'Unknown user';
$string['settings'] = 'Redirect Plus Settings';
$string['settingsinfo'] = 'Plugin Information';
$string['settingsinfodesc'] = 'This plugin automatically logs all 404 errors that occur on your Moodle site. View the error report from Site administration > Tools > Redirect Plus.';

// Privacy strings.
$string['privacy:metadata:tool_redirectplus_404'] = 'Information about 404 errors encountered by users.';
$string['privacy:metadata:tool_redirectplus_404:userid'] = 'The ID of the user who encountered the 404 error.';
$string['privacy:metadata:tool_redirectplus_404:url'] = 'The URL that generated the 404 error.';
$string['privacy:metadata:tool_redirectplus_404:referrer'] = 'The URL the user came from (referrer).';
$string['privacy:metadata:tool_redirectplus_404:ip'] = 'The IP address of the user.';
$string['privacy:metadata:tool_redirectplus_404:useragent'] = 'The user agent (browser) information.';
$string['privacy:metadata:tool_redirectplus_404:timecreated'] = 'The time when the 404 error was encountered.';
