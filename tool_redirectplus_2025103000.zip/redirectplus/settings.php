<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Plugin administration pages are defined here.
 *
 * @package     tool_redirectplus
 * @category    admin
 * @copyright   2025 G Wiz IT Solutions <support@gwizit.com>
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

if ($hassiteconfig) {
    // Create a link to the 404 error report page.
    $ADMIN->add('tools', new admin_externalpage(
        'tool_redirectplus_report',
        new lang_string('pluginname', 'tool_redirectplus'),
        new moodle_url('/admin/tool/redirectplus/index.php'),
        'moodle/site:config'
    ));

    // Settings page - currently empty but ready for future configuration options.
    $settings = new admin_settingpage('tool_redirectplus_settings', new lang_string('settings', 'tool_redirectplus'));

    if ($ADMIN->fulltree) {
        // Add an informational heading.
        $settings->add(new admin_setting_heading(
            'tool_redirectplus/info',
            get_string('settingsinfo', 'tool_redirectplus'),
            get_string('settingsinfodesc', 'tool_redirectplus')
        ));
    }

    // Add settings to the admin tree (Tools category).
    $ADMIN->add('tools', $settings);
}
