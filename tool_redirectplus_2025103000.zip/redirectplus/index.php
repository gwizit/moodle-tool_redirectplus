<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * 404 Error Report Page.
 *
 * @package     tool_redirectplus
 * @copyright   2025 G Wiz IT Solutions <support@gwizit.com>
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(__DIR__ . '/../../../config.php');
require_once($CFG->libdir . '/adminlib.php');
require_once($CFG->libdir . '/tablelib.php');

admin_externalpage_setup('tool_redirectplus_report');

$tool_redirectplus_page = optional_param('page', 0, PARAM_INT);
$tool_redirectplus_perpage = optional_param('perpage', 50, PARAM_INT);
$tool_redirectplus_delete = optional_param('delete', 0, PARAM_INT);
$tool_redirectplus_deleteall = optional_param('deleteall', 0, PARAM_BOOL);
$tool_redirectplus_confirm = optional_param('confirm', 0, PARAM_BOOL);

$tool_redirectplus_context = context_system::instance();
require_capability('moodle/site:config', $tool_redirectplus_context);

$PAGE->set_url('/admin/tool/redirectplus/index.php', ['page' => $tool_redirectplus_page, 'perpage' => $tool_redirectplus_perpage]);
$PAGE->set_context($tool_redirectplus_context);
$PAGE->set_title(get_string('pluginname', 'tool_redirectplus'));
$PAGE->set_heading(get_string('pluginname', 'tool_redirectplus'));

// Handle delete single record.
if ($tool_redirectplus_delete && confirm_sesskey()) {
    if ($tool_redirectplus_confirm) {
        $DB->delete_records('tool_redirectplus_404', ['id' => $tool_redirectplus_delete]);
        redirect($PAGE->url, get_string('recorddeleted', 'tool_redirectplus'), null, \core\output\notification::NOTIFY_SUCCESS);
    } else {
        echo $OUTPUT->header();
        echo $OUTPUT->heading(get_string('deleterecord', 'tool_redirectplus'));
        $tool_redirectplus_confirmurl = new moodle_url($PAGE->url, [
            'delete' => $tool_redirectplus_delete,
            'confirm' => 1,
            'sesskey' => sesskey(),
        ]);
        echo $OUTPUT->confirm(
            get_string('deleterecordconfirm', 'tool_redirectplus'),
            $tool_redirectplus_confirmurl,
            $PAGE->url
        );
        echo $OUTPUT->footer();
        die();
    }
}

// Handle delete all records.
if ($tool_redirectplus_deleteall && confirm_sesskey()) {
    if ($tool_redirectplus_confirm) {
        $DB->delete_records('tool_redirectplus_404');
        redirect($PAGE->url, get_string('allrecordsdeleted', 'tool_redirectplus'), null, \core\output\notification::NOTIFY_SUCCESS);
    } else {
        echo $OUTPUT->header();
        echo $OUTPUT->heading(get_string('deleteallrecords', 'tool_redirectplus'));
        $tool_redirectplus_confirmurl = new moodle_url($PAGE->url, [
            'deleteall' => 1,
            'confirm' => 1,
            'sesskey' => sesskey(),
        ]);
        echo $OUTPUT->confirm(
            get_string('deleteallrecordsconfirm', 'tool_redirectplus'),
            $tool_redirectplus_confirmurl,
            $PAGE->url
        );
        echo $OUTPUT->footer();
        die();
    }
}

echo $OUTPUT->header();
echo $OUTPUT->heading(get_string('report404', 'tool_redirectplus'));

// Display introduction.
echo html_writer::tag('p', get_string('report404desc', 'tool_redirectplus'));

// Count total records.
$tool_redirectplus_totalcount = $DB->count_records('tool_redirectplus_404');

if ($tool_redirectplus_totalcount == 0) {
    echo $OUTPUT->notification(get_string('no404errors', 'tool_redirectplus'), \core\output\notification::NOTIFY_INFO);
    echo $OUTPUT->footer();
    die();
}

// Display delete all button.
$tool_redirectplus_deleteallurl = new moodle_url($PAGE->url, [
    'deleteall' => 1,
    'sesskey' => sesskey(),
]);
echo html_writer::tag('div',
    html_writer::link($tool_redirectplus_deleteallurl, get_string('deleteallrecords', 'tool_redirectplus'), [
        'class' => 'btn btn-danger mb-3',
    ]),
    ['class' => 'tool-redirectplus-actions']
);

// Create table.
$tool_redirectplus_table = new html_table();
$tool_redirectplus_table->head = [
    get_string('url', 'tool_redirectplus'),
    get_string('referrer', 'tool_redirectplus'),
    get_string('user'),
    get_string('ipaddress', 'tool_redirectplus'),
    get_string('useragent', 'tool_redirectplus'),
    get_string('timecreated', 'tool_redirectplus'),
    get_string('actions'),
];
$tool_redirectplus_table->attributes['class'] = 'admintable generaltable';
$tool_redirectplus_table->id = 'tool_redirectplus_report';

// Get records.
$tool_redirectplus_records = $DB->get_records('tool_redirectplus_404', null, 'timecreated DESC',
    '*', $tool_redirectplus_page * $tool_redirectplus_perpage, $tool_redirectplus_perpage);

foreach ($tool_redirectplus_records as $tool_redirectplus_record) {
    $tool_redirectplus_row = [];
    
    // URL - truncate if too long.
    $tool_redirectplus_url = $tool_redirectplus_record->url;
    if (strlen($tool_redirectplus_url) > 80) {
        $tool_redirectplus_url = substr($tool_redirectplus_url, 0, 80) . '...';
    }
    $tool_redirectplus_row[] = html_writer::tag('span', s($tool_redirectplus_url), [
        'title' => s($tool_redirectplus_record->url),
    ]);
    
    // Referrer.
    $tool_redirectplus_referrer = $tool_redirectplus_record->referrer ?: '-';
    if (strlen($tool_redirectplus_referrer) > 50) {
        $tool_redirectplus_referrer = substr($tool_redirectplus_referrer, 0, 50) . '...';
    }
    $tool_redirectplus_row[] = html_writer::tag('span', s($tool_redirectplus_referrer), [
        'title' => s($tool_redirectplus_record->referrer),
    ]);
    
    // User.
    if ($tool_redirectplus_record->userid > 0) {
        try {
            $tool_redirectplus_user = $DB->get_record('user', ['id' => $tool_redirectplus_record->userid]);
            if ($tool_redirectplus_user) {
                $tool_redirectplus_userlink = html_writer::link(
                    new moodle_url('/user/profile.php', ['id' => $tool_redirectplus_user->id]),
                    fullname($tool_redirectplus_user)
                );
                $tool_redirectplus_row[] = $tool_redirectplus_userlink;
            } else {
                $tool_redirectplus_row[] = get_string('deleteduser', 'tool_redirectplus');
            }
        } catch (Exception $e) {
            $tool_redirectplus_row[] = get_string('unknownuser', 'tool_redirectplus');
        }
    } else {
        $tool_redirectplus_row[] = get_string('guest');
    }
    
    // IP Address.
    $tool_redirectplus_row[] = s($tool_redirectplus_record->ip);
    
    // User Agent - truncate if too long.
    $tool_redirectplus_useragent = $tool_redirectplus_record->useragent ?: '-';
    if (strlen($tool_redirectplus_useragent) > 60) {
        $tool_redirectplus_useragent = substr($tool_redirectplus_useragent, 0, 60) . '...';
    }
    $tool_redirectplus_row[] = html_writer::tag('span', s($tool_redirectplus_useragent), [
        'title' => s($tool_redirectplus_record->useragent),
    ]);
    
    // Time created.
    $tool_redirectplus_row[] = userdate($tool_redirectplus_record->timecreated);
    
    // Actions.
    $tool_redirectplus_deleteurl = new moodle_url($PAGE->url, [
        'delete' => $tool_redirectplus_record->id,
        'sesskey' => sesskey(),
    ]);
    $tool_redirectplus_row[] = html_writer::link($tool_redirectplus_deleteurl, get_string('delete'), [
        'class' => 'btn btn-sm btn-danger',
    ]);
    
    $tool_redirectplus_table->data[] = $tool_redirectplus_row;
}

echo html_writer::table($tool_redirectplus_table);

// Pagination.
echo $OUTPUT->paging_bar($tool_redirectplus_totalcount, $tool_redirectplus_page, $tool_redirectplus_perpage, $PAGE->url);

echo $OUTPUT->footer();
